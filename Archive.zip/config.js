module.exports = {
    secret: "house nail temple cross",
    database : 'mongodb://localhost/property-manager'
};